//! T03 (KR-03 / KR-07): the budget and the context window are decided by trusted sources, and the
//! whole request is checked before it is sent.
//!
//! Covered here:
//! * a workspace `.kroma.toml` may lower the host ceiling but never raise it (tokens, concurrency);
//! * capabilities are resolved with an explicit provenance, and an unknown model falls back to a
//!   conservative window instead of an invented spec;
//! * the estimator is conservative for CJK text and counts image payloads;
//! * a request that cannot fit the window is refused *before* transmission, with a structured
//!   event, and the tool schema is part of the calculation;
//! * a smaller window after a resume re-budgets instead of reusing the old watermarks.

use kroma_core::budget::{
    conservative_request_tokens, conservative_text_tokens, BudgetConfig, CapabilitySource,
    HostBudgetCeiling, ModelCapabilities, CONSERVATIVE_CONTEXT_WINDOW_TOKENS,
};
use kroma_core::config_file::{ConfigOverrides, KromaConfigFile, ResolvedConfig};
use kroma_core::messages::{AssistantTurn, FinishReason, TranscriptItem, UserMessage};
use kroma_core::types::TerminalReason;
use std::collections::BTreeMap;

fn resolve(user_toml: &str, workspace_toml: &str) -> ResolvedConfig {
    let user = KromaConfigFile::parse_str(user_toml).expect("user config parses");
    let workspace = KromaConfigFile::parse_str(workspace_toml).expect("workspace config parses");
    ResolvedConfig::resolve(
        &user,
        &workspace,
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    )
}

/// T03: a repository cannot raise its own token ceiling.
#[test]
fn workspace_cannot_raise_host_token_ceiling() {
    // Lowering is a legitimate preference.
    let lowered = resolve("max_tokens = 40000\n", "max_tokens = 10000\n");
    assert_eq!(lowered.max_tokens, Some(10000));
    assert!(lowered.clamped_workspace_keys.is_empty());

    // Raising is clamped to the host ceiling and reported.
    let raised = resolve("max_tokens = 40000\n", "max_tokens = 4000000\n");
    assert_eq!(
        raised.max_tokens,
        Some(40000),
        "a workspace must not be able to raise the host token ceiling"
    );
    assert!(
        raised
            .clamped_workspace_keys
            .iter()
            .any(|k| k.contains("max_tokens") && k.contains("4000000")),
        "the clamp must be visible: {:?}",
        raised.clamped_workspace_keys
    );

    // With no host value, the workspace preference stands on its own.
    let alone = resolve("", "max_tokens = 5000\n");
    assert_eq!(alone.max_tokens, Some(5000));
}

/// T03: and it cannot grant itself more parallel writers either.
#[test]
fn workspace_cannot_raise_host_concurrency() {
    let raised = resolve("max_subagents = 2\n", "max_subagents = 32\n");
    assert_eq!(raised.max_subagents, Some(2));
    assert!(
        raised
            .clamped_workspace_keys
            .iter()
            .any(|k| k.contains("max_subagents")),
        "the clamp must be visible: {:?}",
        raised.clamped_workspace_keys
    );

    let lowered = resolve("max_subagents = 8\n", "max_subagents = 1\n");
    assert_eq!(lowered.max_subagents, Some(1));
    assert!(lowered.clamped_workspace_keys.is_empty());
}

/// T03: capability resolution always says where the number came from.
#[test]
fn unknown_model_falls_back_conservatively_and_records_the_source() {
    let unknown = ModelCapabilities::resolve(None, None);
    assert_eq!(
        unknown.context_window_tokens,
        Some(CONSERVATIVE_CONTEXT_WINDOW_TOKENS)
    );
    assert_eq!(unknown.source, CapabilitySource::ConservativeFallback);
    assert_eq!(unknown.source.as_str(), "conservative_fallback");

    let configured = ModelCapabilities::resolve(Some(128_000), Some(8192));
    assert_eq!(configured.context_window_tokens, Some(128_000));
    assert_eq!(configured.max_output_tokens, Some(8192));
    assert_eq!(configured.source, CapabilitySource::Configured);
    // The output reservation never exceeds the provider cap.
    assert_eq!(configured.reserved_output_tokens(Some(99_999)), 8192);
    assert_eq!(configured.reserved_output_tokens(Some(1024)), 1024);

    let unbounded = ModelCapabilities::resolve(Some(0), None);
    assert_eq!(unbounded.context_window_tokens, None);
    assert_eq!(unbounded.source, CapabilitySource::Unbounded);
}

/// T03: `bytes / 4` is not a tokenizer — CJK must not be under-estimated, and images must count.
#[test]
fn cjk_and_image_budget_is_conservative() {
    let cjk = "你好世界，这是一段中文";
    let ascii = "abcdefghijklmnopqrstuvwxyz";
    let cjk_tokens = conservative_text_tokens(cjk);
    let naive = ((cjk.len() as u64) + 3) / 4;
    assert!(
        cjk_tokens > naive,
        "CJK must not be estimated with bytes/4: {cjk_tokens} vs {naive}"
    );
    // One token per character is the conservative ceiling for CJK.
    assert!(cjk_tokens >= cjk.chars().count() as u64);
    // ASCII stays on the familiar 4-bytes-per-token scale.
    assert_eq!(conservative_text_tokens(ascii), 7);

    // A request that carries an image payload is estimated larger than the same request without it.
    let mut with_image = vec![TranscriptItem::User(UserMessage {
        content: "look at this".to_string(),
    })];
    let text_only = conservative_request_tokens("system", &with_image, 0, 0);
    let meta = kroma_core::messages::ToolResultMeta {
        image_attachments: vec![kroma_core::messages::ImageAttachment {
            mime_type: "image/png".to_string(),
            base64_data: "A".repeat(4000).into(),
            width: Some(64),
            height: Some(64),
            byte_len: 3000,
        }],
        ..Default::default()
    };
    with_image.push(TranscriptItem::ToolResult(
        kroma_core::messages::ToolResultMessage {
            call_id: kroma_core::types::ToolCallId::new("call_img"),
            tool_name: "read".to_string(),
            outcome: kroma_core::messages::ToolOutcome::Success,
            content: "attached".into(),
            meta,
        },
    ));
    let with_image_tokens = conservative_request_tokens("system", &with_image, 0, 0);
    assert!(
        with_image_tokens > text_only + 900,
        "image payload bytes must be charged: {with_image_tokens} vs {text_only}"
    );
}

/// T03: the tool schema and the serialization overhead are part of the request estimate.
#[test]
fn task_contract_and_tool_schema_count_toward_context() {
    let items = vec![TranscriptItem::User(UserMessage {
        content: "hi".to_string(),
    })];
    let without = conservative_request_tokens("system", &items, 0, 0);
    let with_schema = conservative_request_tokens("system", &items, 40_000, 0);
    assert!(
        with_schema >= without + 9_000,
        "a 40 KB tool schema must add roughly 10k tokens: {without} -> {with_schema}"
    );
    let with_overhead = conservative_request_tokens("system", &items, 0, 4_000);
    assert!(with_overhead >= without + 900);
}

/// T03: a smaller window after a resume re-budgets instead of reusing the old watermarks.
#[test]
fn resume_and_switch_to_smaller_window_rebudgets() {
    let large = BudgetConfig {
        model_context_window_tokens: Some(200_000),
        ..Default::default()
    };
    let small = BudgetConfig {
        model_context_window_tokens: Some(16_000),
        ..Default::default()
    };
    let (large_high, large_low) = large.token_watermarks().expect("configured window");
    let (small_high, small_low) = small.token_watermarks().expect("configured window");
    assert!(small_high < large_high && small_low < large_low);
    assert_eq!(small_high, 12_000);
    assert_eq!(small_low, 7_200);

    // A run constructed with no window is re-budgeted to the conservative fallback, not left
    // unbounded: the resolved capability is what the projector uses.
    let fallback = ModelCapabilities::resolve(None, None);
    assert_eq!(
        fallback.context_window_tokens,
        Some(CONSERVATIVE_CONTEXT_WINDOW_TOKENS)
    );
    assert!(BudgetConfig {
        model_context_window_tokens: fallback.context_window_tokens,
        ..Default::default()
    }
    .token_watermarks()
    .is_some());
}

/// T03: the ceiling arithmetic itself.
#[test]
fn host_ceiling_clamps_and_reports() {
    let ceiling = HostBudgetCeiling {
        max_total_tokens: Some(1000),
        max_subagents: Some(3),
        context_window_tokens: Some(64_000),
    };
    assert_eq!(ceiling.clamp_tokens(Some(500)).effective, Some(500));
    assert!(!ceiling.clamp_tokens(Some(500)).clamped);
    assert_eq!(ceiling.clamp_tokens(Some(9999)).effective, Some(1000));
    assert!(ceiling.clamp_tokens(Some(9999)).clamped);
    assert_eq!(ceiling.clamp_subagents(Some(9)).effective, Some(3));
    assert_eq!(
        ceiling.clamp_window(Some(1_000_000)).effective,
        Some(64_000)
    );
}

// ---------------------------------------------------------------------------------------------
// Pre-send check
// ---------------------------------------------------------------------------------------------

#[tokio::test]
async fn a_request_that_cannot_fit_the_window_is_never_sent() {
    use kroma_core::agent_loop::{build_default_runtime, AgentRunConfig, AgentRunner};
    use kroma_core::events::EventLogger;
    use kroma_core::provider::{ModelProvider, ProviderCompletion, ProviderError, ProviderRequest};
    use kroma_core::revision::SnapshotStore;
    use kroma_core::session::SessionJournal;
    use kroma_core::tool::policy::{NonInteractiveApprovalHandler, PolicyEngine, PolicyMode};
    use std::future::Future;
    use std::pin::Pin;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::Arc;

    struct CountingProvider {
        calls: Arc<AtomicUsize>,
    }

    impl ModelProvider for CountingProvider {
        fn complete<'a>(
            &'a self,
            _req: ProviderRequest,
            _budget: &'a BudgetConfig,
            _cancel_rx: tokio::sync::watch::Receiver<bool>,
        ) -> Pin<Box<dyn Future<Output = Result<ProviderCompletion, ProviderError>> + Send + 'a>>
        {
            self.calls.fetch_add(1, Ordering::SeqCst);
            Box::pin(async move {
                Ok(ProviderCompletion {
                    turn: AssistantTurn {
                        content: Some("should never be reached".to_string()),
                        reasoning_blocks: Vec::new(),
                        tool_calls: Vec::new(),
                        finish_reason: FinishReason::Stop,
                        usage: None,
                    },
                    request_body_bytes: 1,
                    latency_ms: 1,
                    ttft_ms: None,
                    attempts_used: 1,
                    reported_model: None,
                })
            })
        }
    }

    let root = std::env::temp_dir().join(format!("kroma-t03-window-{}", uuid::Uuid::new_v4()));
    let ws = root.join("ws");
    let state = root.join("state");
    std::fs::create_dir_all(&ws).unwrap();
    std::fs::create_dir_all(&state).unwrap();
    std::fs::write(ws.join("lib.rs"), "pub fn a() {}\n").unwrap();

    let calls = Arc::new(AtomicUsize::new(0));
    let provider = Arc::new(CountingProvider {
        calls: Arc::clone(&calls),
    });
    let env = Arc::new(kroma_core::env::LocalHostEnv::new(&ws, state.clone()).unwrap());
    let policy = PolicyEngine::new(
        PolicyMode::FullAutonomous,
        Arc::new(NonInteractiveApprovalHandler),
    );
    // 600 tokens: smaller than the default system prompt + tool schemas of a real run.
    let budget = BudgetConfig {
        model_context_window_tokens: Some(600),
        ..Default::default()
    };
    let runtime = build_default_runtime(env, policy, budget.clone(), None);
    let cfg = AgentRunConfig::new("do something", budget);
    let run_id = cfg.run_id;
    let logger = EventLogger::new(run_id, Some(state.clone()), true).unwrap();
    let journal = SessionJournal::create(state.join("sessions"), &ws).unwrap();
    let store = Arc::new(SnapshotStore::new(root.join("snapshots")));
    let (_tx, rx) = tokio::sync::watch::channel(false);

    let (summary, _logger) = AgentRunner::new(cfg, provider, runtime, rx)
        .with_session_journal(journal)
        .with_snapshot_store(store)
        .run(logger)
        .await;

    assert_eq!(
        summary.terminal_reason,
        TerminalReason::ContextBudgetExceeded,
        "a request that cannot fit the window must be refused, not sent"
    );
    assert_eq!(
        calls.load(Ordering::SeqCst),
        0,
        "zero provider calls: the check runs before transmission"
    );

    let log = std::fs::read_to_string(state.join(format!("{}.jsonl", run_id))).unwrap_or_default();
    assert!(
        log.contains("context_budget_exceeded"),
        "the refusal must be recorded structurally; log:\n{log}"
    );
    assert!(
        log.contains("configured"),
        "the window source must be recorded; log:\n{log}"
    );

    let _ = std::fs::remove_dir_all(&root);
}

// ---------------------------------------------------------------------------------------------
// Compaction before the first over-window request
// ---------------------------------------------------------------------------------------------

/// T03: on a `--resume` with no restored provider usage, a small window must compact *before* the
/// first request is transmitted, not after an over-window request has already gone out.
#[tokio::test]
async fn small_context_compacts_before_first_overflow_request() {
    use kroma_core::agent_loop::{build_default_runtime, AgentRunConfig, AgentRunner};
    use kroma_core::events::EventLogger;
    use kroma_core::messages::{AssistantTurn, FinishReason, ToolCall};
    use kroma_core::provider::{ModelProvider, ProviderCompletion, ProviderError, ProviderRequest};
    use kroma_core::revision::SnapshotStore;
    use kroma_core::session::SessionJournal;
    use kroma_core::tool::policy::{NonInteractiveApprovalHandler, PolicyEngine, PolicyMode};
    use kroma_core::types::ToolCallId;
    use std::future::Future;
    use std::pin::Pin;
    use std::sync::{Arc, Mutex};

    /// Records the conservative token size of every request it is asked to send.
    struct RecordingProvider {
        turns: Mutex<std::collections::VecDeque<AssistantTurn>>,
        seen_tokens: Arc<Mutex<Vec<u64>>>,
    }

    impl ModelProvider for RecordingProvider {
        fn complete<'a>(
            &'a self,
            req: ProviderRequest,
            _budget: &'a BudgetConfig,
            _cancel_rx: tokio::sync::watch::Receiver<bool>,
        ) -> Pin<Box<dyn Future<Output = Result<ProviderCompletion, ProviderError>> + Send + 'a>>
        {
            let tools_bytes: usize = req
                .tools
                .iter()
                .map(|t| t.name.len() + t.description.len() + 256)
                .sum();
            self.seen_tokens
                .lock()
                .unwrap()
                .push(conservative_request_tokens(
                    &req.system_prompt,
                    &req.messages,
                    tools_bytes,
                    1024,
                ));
            let turn = self
                .turns
                .lock()
                .unwrap()
                .pop_front()
                .expect("scripted turn");
            Box::pin(async move {
                Ok(ProviderCompletion {
                    turn,
                    request_body_bytes: 1,
                    latency_ms: 1,
                    ttft_ms: None,
                    attempts_used: 1,
                    reported_model: None,
                })
            })
        }
    }

    let root = std::env::temp_dir().join(format!("kroma-t03-compact-{}", uuid::Uuid::new_v4()));
    let ws = root.join("ws");
    let state = root.join("state");
    std::fs::create_dir_all(&ws).unwrap();
    std::fs::create_dir_all(&state).unwrap();
    // Sixteen distinct sources, each below the `read` output cap, so run 1 builds a history far
    // larger than the window used by the resumed run.
    const SOURCES: usize = 16;
    for idx in 0..SOURCES {
        let mut body = String::new();
        for line in 0..1_000 {
            body.push_str(&format!(
                "pub fn filler_{idx}_{line}() -> usize {{ {line} }}\n"
            ));
        }
        std::fs::write(ws.join(format!("filler_{idx}.rs")), body).unwrap();
    }

    let read_turns: Vec<AssistantTurn> = (0..SOURCES)
        .map(|idx| AssistantTurn {
            content: None,
            reasoning_blocks: Vec::new(),
            tool_calls: vec![ToolCall {
                call_id: ToolCallId::new(format!("call_read_{idx}")),
                name: "read".to_string(),
                raw_arguments: format!(r#"{{"path":"filler_{idx}.rs"}}"#),
            }],
            finish_reason: FinishReason::ToolCalls,
            usage: None,
        })
        .chain(std::iter::once(AssistantTurn {
            content: Some("done".to_string()),
            reasoning_blocks: Vec::new(),
            tool_calls: Vec::new(),
            finish_reason: FinishReason::Stop,
            usage: None,
        }))
        .collect();

    let wide = BudgetConfig {
        max_model_turns: 32,
        max_tool_calls: 64,
        max_total_tool_output_bytes: 4 * 1024 * 1024,
        context_high_watermark_bytes: 4 * 1024 * 1024,
        context_low_watermark_bytes: 2 * 1024 * 1024,
        ..Default::default()
    };
    let env = Arc::new(kroma_core::env::LocalHostEnv::new(&ws, state.clone()).unwrap());
    let policy = PolicyEngine::new(
        PolicyMode::ReadOnly,
        Arc::new(NonInteractiveApprovalHandler),
    );
    let runtime = build_default_runtime(env, policy, wide.clone(), None);
    let cfg = AgentRunConfig::new("read the sources", wide.clone());
    let logger = EventLogger::new(cfg.run_id, Some(state.clone()), true).unwrap();
    let journal = SessionJournal::create(state.join("sessions"), &ws).unwrap();
    let wal_path = journal.path().to_path_buf();
    let (_tx, rx) = tokio::sync::watch::channel(false);
    let (first, _logger) = AgentRunner::new(
        cfg,
        Arc::new(RecordingProvider {
            turns: Mutex::new(read_turns.into_iter().collect()),
            seen_tokens: Arc::new(Mutex::new(Vec::new())),
        }),
        runtime,
        rx,
    )
    .with_session_journal(journal)
    .run(logger)
    .await;
    assert_eq!(first.status, kroma_core::types::RunStatus::Completed);

    let history_bytes: usize = first
        .transcript
        .iter()
        .map(TranscriptItem::estimated_bytes)
        .sum();

    // The restored history is ~730 KB (~245k conservative tokens), so the first request of the
    // resumed run is over-window *before* compaction and fits after it. The window is deliberately
    // larger than Kroma's own static prefix: this test is about compaction, not about a window that
    // no prompt could ever fit.
    const WINDOW: u64 = 200_000;
    assert!(
        kroma_core::budget::conservative_bytes_tokens(history_bytes) > WINDOW,
        "the fixture history must exceed the window: {history_bytes} bytes"
    );

    let narrow = BudgetConfig {
        model_context_window_tokens: Some(WINDOW),
        max_model_turns: 16,
        max_tool_calls: 32,
        ..Default::default()
    };
    let resumed_journal = SessionJournal::open(&wal_path).unwrap();
    let seen = Arc::new(Mutex::new(Vec::new()));
    let env = Arc::new(kroma_core::env::LocalHostEnv::new(&ws, state.clone()).unwrap());
    let policy = PolicyEngine::new(
        PolicyMode::ReadOnly,
        Arc::new(NonInteractiveApprovalHandler),
    );
    let runtime = build_default_runtime(env, policy, narrow.clone(), None);
    let cfg = AgentRunConfig::new("summarise", narrow);
    let run_id = cfg.run_id;
    let logger = EventLogger::new(run_id, Some(state.clone()), true).unwrap();
    let (_tx, rx) = tokio::sync::watch::channel(false);
    let (second, _logger) = AgentRunner::new(
        cfg,
        Arc::new(RecordingProvider {
            turns: Mutex::new(
                vec![AssistantTurn {
                    content: Some("summarised".to_string()),
                    reasoning_blocks: Vec::new(),
                    tool_calls: Vec::new(),
                    finish_reason: FinishReason::Stop,
                    usage: None,
                }]
                .into_iter()
                .collect(),
            ),
            seen_tokens: Arc::clone(&seen),
        }),
        runtime,
        rx,
    )
    .with_session_journal(resumed_journal)
    .with_snapshot_store(Arc::new(SnapshotStore::new(root.join("snapshots"))))
    .run(logger)
    .await;

    let seen = seen.lock().unwrap().clone();
    assert!(
        !seen.is_empty(),
        "the resumed run must have sent a request (terminal={:?}, history_bytes={history_bytes})",
        second.terminal_reason
    );
    assert!(
        seen[0] <= WINDOW,
        "the first resumed request was over-window ({} tokens > {WINDOW}): compaction must run \
         before transmission",
        seen[0]
    );
    assert_eq!(second.status, kroma_core::types::RunStatus::Completed);

    let log = std::fs::read_to_string(state.join(format!("{}.jsonl", run_id))).unwrap_or_default();
    assert!(
        log.contains("ContextCompacted"),
        "compaction must be recorded structurally; log:\n{log}"
    );

    let _ = std::fs::remove_dir_all(&root);
}

/// T03: a workspace may not select a model outside the operator's allow-list, and it may not
/// declare the allow-list either.
#[test]
fn workspace_model_outside_allowlist_is_refused() {
    let user = KromaConfigFile::parse_str(
        "allowed_models = \"cheap-model,mid-model\"\nmodel = \"mid-model\"\n",
    )
    .expect("user config parses");
    assert_eq!(
        user.allowed_models.as_deref(),
        Some("cheap-model,mid-model")
    );

    // Outside the allow-list: refused, and the operator's model is what runs.
    let outside = KromaConfigFile::parse_str("model = \"expensive-model\"\n").unwrap();
    let resolved = ResolvedConfig::resolve(
        &user,
        &outside,
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    );
    assert_eq!(resolved.model.as_deref(), Some("mid-model"));
    assert!(
        resolved
            .refused_workspace_keys
            .iter()
            .any(|k| k.contains("expensive-model")),
        "the refusal must be visible: {:?}",
        resolved.refused_workspace_keys
    );
    assert_eq!(
        resolved.allowed_models.as_deref(),
        Some(&["cheap-model".to_string(), "mid-model".to_string()][..])
    );

    // Inside the allow-list: honoured as before.
    let inside = KromaConfigFile::parse_str("model = \"cheap-model\"\n").unwrap();
    let resolved = ResolvedConfig::resolve(
        &user,
        &inside,
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    );
    assert_eq!(resolved.model.as_deref(), Some("cheap-model"));
    assert!(resolved.refused_workspace_keys.is_empty());

    // With no allow-list configured nothing is refused.
    let no_list = KromaConfigFile::parse_str("model = \"anything\"\n").unwrap();
    let resolved = ResolvedConfig::resolve(
        &KromaConfigFile::default(),
        &no_list,
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    );
    assert_eq!(resolved.model.as_deref(), Some("anything"));
    assert!(resolved.allowed_models.is_none());

    // The allow-list itself is operator-only: a workspace cannot widen it.
    let hostile = KromaConfigFile::parse_str("allowed_models = \"*\"\n").unwrap();
    let resolved = ResolvedConfig::resolve(
        &user,
        &hostile,
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    );
    assert!(
        resolved
            .rejected_workspace_keys
            .iter()
            .any(|k| k == "allowed_models"),
        "a workspace must not be able to declare the allow-list: {:?}",
        resolved.rejected_workspace_keys
    );
    assert_eq!(
        resolved.allowed_models.as_deref(),
        Some(&["cheap-model".to_string(), "mid-model".to_string()][..])
    );
}

/// T03: a live configuration change must not expand a grant that was already approved.
#[test]
fn live_reconfiguration_does_not_expand_existing_task_grant() {
    use kroma_core::subagents::{CanonicalTournamentBudget, CanonicalTournamentIntent};

    let intent_for = |budget: &BudgetConfig| CanonicalTournamentIntent {
        task: "fix the failing add()".to_string(),
        candidates: 2,
        strategies: vec!["smallest change".to_string(), "defensive fix".to_string()],
        allowed_paths: Some(vec!["src/**".to_string()]),
        max_turns: Some(6),
        timeout_ms: 30_000,
        disallow_test_tampering: true,
        protected_paths: vec!["tests/**".to_string()],
        require_verified: true,
        verification_policy_source: "host_strict".to_string(),
        budget: CanonicalTournamentBudget::from_config(budget),
        predictive_check: true,
    };

    let narrow = BudgetConfig {
        max_total_tokens: Some(1_000),
        max_model_turns: 4,
        ..Default::default()
    };
    let approved = intent_for(&narrow);
    let approved_digest = approved.digest();

    // The operator widens the ceiling while the approval is outstanding.
    let widened = BudgetConfig {
        max_total_tokens: Some(5_000),
        max_model_turns: 32,
        ..Default::default()
    };
    let live = intent_for(&widened);

    assert_ne!(
        live.digest(),
        approved_digest,
        "a widened live configuration must not silently produce the approved intent"
    );
    // The approved object still carries the numbers the human saw.
    assert_eq!(approved.budget.max_total_tokens, Some(1_000));
    assert_eq!(approved.budget.max_model_turns, 4);
    assert_eq!(live.budget.max_total_tokens, Some(5_000));

    // And the widened intent is not covered by the grant that was issued for the narrow one.
    let approver = std::sync::Arc::new(kroma_core::tool::policy::NonInteractiveApprovalHandler);
    let engine = kroma_core::tool::policy::PolicyEngine::new(
        kroma_core::tool::policy::PolicyMode::FullAutonomous,
        approver,
    );
    let scope = kroma_core::tool::policy::AuthScope {
        entry: kroma_core::tool::policy::AuthEntry::Tournament,
        tool_name: "spawn_subagent".to_string(),
        run_id: None,
        workspace_root: std::path::PathBuf::from("/ws"),
        revision: Some(kroma_core::revision::RevisionId::new(
            "r-00000000000000000000000000000003",
        )),
    };
    assert!(
        engine.consume_grant(&scope, &live.digest()).is_err(),
        "a grant approved for the narrow budget must not authorize the widened one"
    );
}

/// T03: the resolved configuration must *show* where a ceiling came from and what it clamped or
/// refused, so an operator never has to guess why a value did not apply.
#[test]
fn config_source_display_shows_the_ceiling_and_every_clamp() {
    let user = KromaConfigFile::parse_str(
        "allowed_models = \"cheap-model,mid-model\"\nmax_tokens = 40000\nmodel = \"mid-model\"\n",
    )
    .unwrap();
    let workspace =
        KromaConfigFile::parse_str("max_tokens = 4000000\nmodel = \"expensive-model\"\n").unwrap();
    let resolved = ResolvedConfig::resolve(
        &user,
        &workspace,
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    );
    let summary = resolved.redacted_summary();
    assert!(
        summary.contains("allowed_models:   cheap-model, mid-model"),
        "{summary}"
    );
    assert!(
        summary.contains("clamped:"),
        "the clamp must be visible: {summary}"
    );
    assert!(summary.contains("4000000"), "{summary}");
    assert!(
        summary.contains("refused:"),
        "the refusal must be visible: {summary}"
    );
    assert!(summary.contains("expensive-model"), "{summary}");

    // Unrestricted runs say so instead of printing nothing.
    let plain = ResolvedConfig::resolve(
        &KromaConfigFile::default(),
        &KromaConfigFile::default(),
        &BTreeMap::new(),
        &ConfigOverrides::default(),
        None,
        std::path::PathBuf::from("/ws/.kroma.toml"),
    );
    assert!(plain
        .redacted_summary()
        .contains("allowed_models:   (unrestricted)"));
}
